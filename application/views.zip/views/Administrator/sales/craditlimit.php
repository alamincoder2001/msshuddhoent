<input type="hidden" id="customerdue" value="<?php echo $totaldue; ?>">
<input type="hidden" id="craditlimits" value="<?php echo $craditlimit; ?>">