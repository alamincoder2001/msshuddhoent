<div class="form-group">
	<label class="col-sm-4 control-label" for="Product_id"> Salary Range </label>
	<label class="col-sm-1 control-label">:</label>
	<div class="col-sm-6">
		<input type="text" name="salary_range" id="salary_range" value="<?php echo $employee->salary_range; ?>" class="form-control" readonly />
	</div>
</div>
