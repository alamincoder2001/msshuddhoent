
<div class="row">

<div class="col-xs-8">
	<!-- PAGE CONTENT BEGINS -->
	<div class="form-horizontal">
		<div class="form-group">
			<div class="col-sm-12" > <h4>Purchase Excel File Formate</h4>  </div>
			
			<div class="col-sm-12">
			
				<iframe src="<?php echo base_url(); ?>uploads/file.png" width="100%" height="500"></iframe>
			</div>
		</div>
		
</div>
</div>

<div class="col-xs-4">
	<!-- PAGE CONTENT BEGINS -->
	<div class="form-horizontal">
	<div class="col-sm-12" > <h4>Purchase Excel File Download</h4>  </div>
		<div class="col-sm-12">
			<a href="<?php echo base_url(); ?>uploads/purchase_formate.xlsx" download class="btn btn-sm btn-primary"> Download <i class="fa fa-download" aria-hidden="true"></i></a>
		</div>
		
</div>
</div>

</div>